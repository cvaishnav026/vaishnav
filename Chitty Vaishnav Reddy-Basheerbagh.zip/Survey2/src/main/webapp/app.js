



var radios = document.getElementsByName('sur1');
var sur1 = '';
for(var i=0;i<radios.length;i++)
{
	var c1=0;
   if(radios[i].checked)
      sur1 = radios[i].value;
   c1++;
}

var obj={
       
        "sur1" : sur1
    }

var radios = document.getElementsByName('sur2');
var sur2 = '';
for(var i=0;i<radios.length;i++)
{
	var c2=0;
   if(radios[i].checked)
      sur2 = radios[i].value;
   c2++;
}

var obj1={
       
        "sur2" : sur2
    }
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
    $scope.survey = "obj.sur1";
    $scope.survey = "obj1.sur2";
});
/*myApp.controller('MainCtrl', function($scope, localStorageService) {
  //... 
  function submit(sur,sur) {
   return localStorageService.set(sur, sur);
  }
  //...
  function getItem(key) {
	   return localStorageService.get(sur);
	  }
});*/